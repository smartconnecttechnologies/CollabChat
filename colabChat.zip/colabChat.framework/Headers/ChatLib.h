//
//  ChatLib.h
//  ChatLib
//
//  Created by SmartConnect Technologies on 05/04/21.
//

#import <Foundation/Foundation.h>

//! Project version number for ChatLib.
FOUNDATION_EXPORT double ChatLibVersionNumber;

//! Project version string for ChatLib.
FOUNDATION_EXPORT const unsigned char ChatLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ChatLib/PublicHeader.h>


